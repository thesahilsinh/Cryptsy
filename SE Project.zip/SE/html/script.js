const element = document.getElementById(01);

console.log(element)


